import 'package:json_annotation/json_annotation.dart';

part 'movie_model.g.dart'; // [cite: 3]

@JsonSerializable()
class MovieModel { // هذا الاسم صحيح هنا
  final int id;
  final bool adult;
  final String title;
  final String overview;
  final bool video;
  
  @JsonKey(name: 'backdrop_path')
  final String? backdropPath; 

  @JsonKey(name: 'genre_ids')
  final List<int> genreIds;

  @JsonKey(name: 'original_language')
  final String originalLanguage;

  @JsonKey(name: 'original_title')
  final String originalTitle;

  @JsonKey(name: 'poster_path')
  final String? posterPath; 

  @JsonKey(name: 'release_date')
  final String releaseDate;

  @JsonKey(name: 'vote_average')
  final double voteAverage;

  @JsonKey(name: 'vote_count')
  final int voteCount;

  final double popularity;

  MovieModel({
    required this.id,
    required this.adult,
    required this.title,
    required this.overview,
    required this.video,
    this.backdropPath,
    required this.genreIds,
    required this.originalLanguage,
    required this.originalTitle,
    this.posterPath,
    required this.releaseDate,
    required this.voteAverage,
    required this.voteCount,
    required this.popularity,
  });

  factory MovieModel.fromJson(Map<String, dynamic> json) => _$MovieModelFromJson(json);

  Map<String, dynamic> toJson() => _$MovieModelToJson(this);
}
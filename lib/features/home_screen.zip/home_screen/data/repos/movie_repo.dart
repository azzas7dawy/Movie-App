
import 'package:maps_and_themeing/features/home_screen/data/datasources/remotly/movie_services.dart';
import 'package:maps_and_themeing/features/home_screen/data/models/movie_model.dart';

 class MovieRepo {
  final MovieServices apiService;
  MovieRepo(this.apiService);
  Future<List<MovieModel>> fetchMovies({required String accountId, required String apiKey, required String sessionId, required String language}) async {

    final response = await apiService.getMovies(
      'account_id',
      'api_key',
      'session_id',
      'language',
    );
    final movies = response.results;
 
    return  movies;
  }
}